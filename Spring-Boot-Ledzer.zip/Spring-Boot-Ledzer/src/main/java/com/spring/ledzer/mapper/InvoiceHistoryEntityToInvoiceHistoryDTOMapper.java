package com.spring.ledzer.mapper;

import com.spring.ledzer.model.Invoice;
import com.spring.ledzer.model.dto.InvoiceHistoryDTO;

public interface InvoiceHistoryEntityToInvoiceHistoryDTOMapper {
	
	public InvoiceHistoryDTO setInvoiceHistoryEntityToInvoiceHistoryDTOMapper(Invoice invoice);

}
