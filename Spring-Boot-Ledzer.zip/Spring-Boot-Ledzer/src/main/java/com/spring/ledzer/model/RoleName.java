package com.spring.ledzer.model;

/**
 * Created by SagarMelmatti on 07/12/17.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
