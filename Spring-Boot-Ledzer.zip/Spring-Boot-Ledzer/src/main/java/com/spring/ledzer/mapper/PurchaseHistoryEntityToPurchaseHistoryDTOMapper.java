package com.spring.ledzer.mapper;

import com.spring.ledzer.model.Purchase;
import com.spring.ledzer.model.dto.PurchaseHistoryDTO;

public interface PurchaseHistoryEntityToPurchaseHistoryDTOMapper {
	
	public PurchaseHistoryDTO setPurchaseHistoryEntityToPurchaseHistoryDTOMapper(Purchase purchase);

}
