package com.spring.ledzer.mapper;

import com.spring.ledzer.model.Purchase;
import com.spring.ledzer.model.dto.PurchaseDTO;

public interface PurchaseEntityToPurchaseDTO {
	
	public PurchaseDTO setPurchaseEntitytoPurchaseDTO(Purchase purchase);

}
