package com.spring.ledzer.fascade;

public interface ProcessAccountTransaction {
	
	public void addAccountTransactions();

}
