package com.spring.ledzer.fascade;

import org.springframework.stereotype.Component;

@Component
public class ProcessAccountTransactionImpl implements ProcessAccountTransaction {

	@Override
	public void addAccountTransactions() {
		// TODO Auto-generated method stub
		
	}

}
