package com.spring.ledzer.mapper;

import com.spring.ledzer.model.PurchaseDetail;
import com.spring.ledzer.model.dto.PurchaseDetailDTO;

public interface PurchaseDetailEntityToPurchaseDetailDTOMapper {
	
	public PurchaseDetailDTO setPurchaseDetailEntityToPurchaseDetailDTO(PurchaseDetail purchaseDetail);

}
