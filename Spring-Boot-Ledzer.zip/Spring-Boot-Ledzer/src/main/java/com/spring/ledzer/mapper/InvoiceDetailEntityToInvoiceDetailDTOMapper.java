package com.spring.ledzer.mapper;

import com.spring.ledzer.model.InvoiceDetail;
import com.spring.ledzer.model.dto.InvoiceDetailDTO;

public interface InvoiceDetailEntityToInvoiceDetailDTOMapper {
	
	public InvoiceDetailDTO setInvoiceDetailEntityToInvoiceDetailDTO(InvoiceDetail invoiceDetail);

}
